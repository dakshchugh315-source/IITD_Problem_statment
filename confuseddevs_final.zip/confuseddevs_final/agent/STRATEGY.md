# Strategy note: team confused_devs

**Final result (ledger at arena close, 17:01):**
- Signed 116/116, 2,494 points, 13,334 credits used, score 1,827.3.
- All 116 signings were made in the first seconds of the market (11:42), with zero rejections.

**Data formats the agent handles (seen in the live API).**
- Skills arrive as one string with mixed separators and spellings: `"Mongodb; Docker; REST; Node"` and `"Redis | Postgres"`. We split on `, ; |` and map synonyms (REST/Rest Apis → rest apis, Postgres → postgresql, Node → nodejs, k8s → kubernetes, sklearn → scikit-learn, A/B tests → a/b testing).
- Experience comes as `"2.6 yrs"`, `"13.5"`, `"27 months"` or `"4+ years"`.
- Expected CTC comes as rupees (`"1070000"`) or lakhs (`"17.9 LPA"`). Both are converted to rupees and compared with the requisition's `max_expected_ctc_lpa`.
- Notice period comes as `"30 days"`, `"Immediate"` or `"2 months"`, and is converted to days.
- The self-reported `assessment` is sometimes empty and is often inflated. `/assess` returns `verified_assessment`, `reference_check` and `identity_verified`.

**What we buy.**
- Recon: 120 search pages per role, which is 120,000 summaries for 1,200 credits.
- Ranking: summaries are ranked locally by normalised skill overlap with the requisition.
- Profiles: full profiles are bought only in batches of 50 (1.2 credits each), for the top candidates per requisition, with a deeper tier where eligible backups were short. In total, 4,640 profiles cost 6,540 credits.
- Assessments: `/assess` was bought for 176 candidates (4,400 credits). About 40 were a calibration set for the model below. The rest were top picks with a doubt: an assessment near the bar, a suspiciously perfect self-score, red-flag notes, or impossible experience.
- LLM: `/reason` was called twice, to score the 100 distinct recruiter notes (about 3 credits).

**What we sign.**
- *Hard bar:* verified assessment ≥ minimum, notice ≤ 60 days, expected CTC ≤ budget, the right role, and not claimed.
- *Rejected:* failed verification (`identity_verified: false`, or a reference check that isn't clean). 11 of the 176 assessed were fakes: they self-reported 85–99 but verified at only 25–54 (all 103 who self-reported exactly 100 were genuine).
- *Quality score:* this follows the organisers' points note. Skill match 35%, assessment margin 25%, salary headroom 15%, recruiter note 15%, notice period 10%.
- *Duplicates:* the same person is detected by a normalised name + city + years key.
- *Outcome:* every one of our 116 signings was verified. Each had a 100% skill match, and the minimum margin over the bar was +11 (average +25).
- *Market open:* offers go out across all requisitions best-first, in parallel, under a client-side throttle of 8.5 requests per second. A rejection falls through to the next backup.

**When we stop.** Offers and assessments pass the rule `expected points > credits × PENALTY_FACTOR`. Searches and profile batches are limited by the hard `MAX_SPEND` ceiling (25,000) and by per-requisition depth caps. Once all slots were full at 11:42, the agent spent nothing more and only polled the free `/ledger`. In closing, offers cost 20, which makes the same rule stricter.

**What the agent learns (learning.py).**
- *Assessment model:* a least-squares fit of verified score on self-reported score, from the paid assessments. It came out as verified ≈ 2.47·self − 152, std 12.7, n=176. Unverified candidates are judged on the prediction minus half a std.
- *Fraud by note:* the agent tracks which notes go with failed verification.
- *Note scores:* each distinct note is scored −2..+2 once by the model, then cached, with a keyword fallback.

**Tuned for PENALTY_FACTOR = 0.05.**
- A credit costs 0.05 points, so a profile costs 0.06 points, an assessment 1.25 and an offer 0.5. Our signings averaged about 21.5 points.
- So information was cheap and a wrong signing was expensive, and we invested in recon and verification.

**Robustness.**
- State (profiles, assessments, signings, spend) is saved to disk atomically after every step. Restarts resumed without re-buying.
- Every error is caught at the top level.
- 429s are avoided by the client-side throttle.
- Empty searches, 409 wrong-phase responses and credit exhaustion each have their own branch.

**Run history (all in the call log).**
- **~10:50–11:05:** 7 manual calls (31 credits) to learn the field formats: `/ledger`, `/requisitions`, 1 search, 2 profiles, 1 assess and 1 `/reason`. No decisions were fed to the agent.
- **11:18:** first start failed on the laptop's missing SSL certificates. We fixed it with `SSL_CERT_FILE` and restarted at 11:19.
- **11:23:** restarted with `ASSESS_BUDGET` raised from 4,000 to 4,400, so 3 planned signings with perfect self-scores could be verified before the market opened.
- **11:49–12:01:** the server briefly reported `closed` during an organiser pause, and the agent treated that as the end and exited. There was no score impact: the signings were held on the server and no credits were spent. The fix: exit only on a `closed` that comes after the `closing` phase has been seen (the `seen_closing` flag, saved in state). We restarted from the saved state at 12:01.

**With two more hours:**
- Release weak signings to upgrade them when the gain exceeds 15 credits × PF.
- Use `/market` price pressure to prioritise contested requisitions.
- Record `/reason` spend in the local ledger.

**AI assistance:** Claude Code (Anthropic) helped write the agent and this note.
